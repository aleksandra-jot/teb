from TestCMS.Lib.PageObjects.CmsPageObjects import HomeObject
from TestCMS.Lib.BaseSetup.BaseTestSetup import BaseTestSetup
import unittest

class TestCmsTask(BaseTestSetup):


    def test_task2_cms(self):
        
        HomeObject(self.driver).clickonpost()
        HomeObject(self.driver).add_comment()
        HomeObject(self.driver).add_name()
        HomeObject(self.driver).add_email()
        HomeObject(self.driver).add_website()
        HomeObject(self.driver).post_comment()
        HomeObject(self.driver).assert_name()
        HomeObject(self.driver).assert_comment()
        

if __name__ == "__main__":
    unittest.main()
        
        