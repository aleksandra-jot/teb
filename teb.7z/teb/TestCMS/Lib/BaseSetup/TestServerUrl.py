class Servertest(object):
    start_url = "https://s1.demo.opensourcecms.com/wordpress/"
