import unittest
from selenium import webdriver
from TestCMS.Lib.BaseSetup.TestServerUrl import Servertest

class BaseTestSetup(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get(Servertest.start_url)

    
    def tearDown(self):
        self.driver.close()