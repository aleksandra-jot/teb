from TestCMS.Lib.PageLocators.HomePageLocators import CmsPageLocators
from TestCMS.Lib.TestData.CommonData import StringGenerator
import string, random, webbrowser

class HomeObject(object):
    def __init__(self, driver):
        self.driver = driver
    
    def clickonpost(self):
    
        url = self.driver.find_elements_by_xpath(CmsPageLocators().recent_post_hello_world)
        url2 = self.driver.find_elements_by_xpath(CmsPageLocators().second_recent_post_hello_world)

        if len(url) ==  1:
            recentpost = self.driver.find_element_by_xpath(CmsPageLocators().recent_post_hello_world)
            recentpost.click()

        elif len(url) == 0 and len(url2) == 1:
            recentpost2 = self.driver.find_element_by_xpath(CmsPageLocators().second_recent_post_hello_world)
            recentpost2.click()

        else: 
            self.driver.get('https://s1.demo.opensourcecms.com/wordpress/2018/10/02/hello-world')
    
    def post_comment(self):
        send_comment = self.driver.find_element_by_xpath(CmsPageLocators.postbtn)
        send_comment.click()

    def add_comment(self):
        global fillcomment
        comment_input = self.driver.find_element_by_xpath(CmsPageLocators().comment_section)
        fillcomment = ("{}".format(StringGenerator(10).generated_string) + " ")*2
        comment_input.send_keys(fillcomment)
    
    def add_name(self):
        global fillname
        name_input = self.driver.find_element_by_xpath(CmsPageLocators().name_section)
        fillname = "{}".format(StringGenerator(7).generated_string) +" "+"{}".format(StringGenerator(10).generated_string)
        name_input.send_keys(fillname)

    def add_email(self):
        email_input = self.driver.find_element_by_xpath(CmsPageLocators().email_section)
        fillemail = "{}@email.ghostinspector.com".format(StringGenerator(5).generated_string)
        email_input.send_keys(fillemail)

    def add_website(self):
        website_input = self.driver.find_element_by_xpath(CmsPageLocators().website_section)
        fillwebsite = "{}.com.pl".format(StringGenerator(5).generated_string)
        website_input.send_keys(fillwebsite)

    def assert_name(self):

        self.locator = CmsPageLocators()
        actual_name_element = self.driver.find_element_by_xpath(self.locator.added_name)
        actual_username = actual_name_element.get_attribute('innerText')
        expected_username = fillname
        print("actual username: " + actual_username)
        print("expected username: " + expected_username)
        assert actual_username == expected_username

    def assert_comment(self):

        self.locator = CmsPageLocators()
        actual_comment_element = self.driver.find_element_by_xpath(self.locator.added_comment)
        actual_comment = actual_comment_element.get_attribute('innerText')
        expected_comment = fillcomment.strip()
        print("actual comment: " + actual_comment)
        print("expected comment: " + expected_comment)
        assert actual_comment == expected_comment
