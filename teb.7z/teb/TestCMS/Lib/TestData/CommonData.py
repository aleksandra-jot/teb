import random, string

class StringGenerator(object):
    def __init__(self, number_of_chars):
        chars = string.ascii_lowercase + string.digits
        self.generated_string = ''.join(random.choice(chars) for _ in range(number_of_chars))