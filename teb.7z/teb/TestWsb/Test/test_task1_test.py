import unittest
from TestWsb.Lib.BaseSetup.BaseTestSetup import BaseTestSetup
from TestWsb.Lib.PageObjects.HomeObjects import HomeObject

class TestWsbTask(BaseTestSetup):

    def test_task1_wsb(self):
        HomeObject(self.driver).clickcourses()
        HomeObject(self.driver).clickfirscycle()
        HomeObject(self.driver).clickfieldspec()
        HomeObject(self.driver).assert_button()
        HomeObject(self.driver).assert_filter()
        HomeObject(self.driver).assert_list()
        HomeObject(self.driver).assert_listsort()
        HomeObject(self.driver).assert_listsearch()
        HomeObject(self.driver).selectcity()
        HomeObject(self.driver).selectkindstudies()
        HomeObject(self.driver).assert_images()
        HomeObject(self.driver).assert_coursescities()
        HomeObject(self.driver).assert_coursesnames()
        
        

if __name__ == "__main__":
    unittest.main()
        


