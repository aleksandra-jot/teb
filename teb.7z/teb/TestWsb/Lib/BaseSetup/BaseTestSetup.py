import unittest
from selenium import webdriver
from TestWsb.Lib.BaseSetup.TestServerUrl import Servertest

class BaseTestSetup(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get(Servertest.start_url)
        assert 'Strona główna | wsb.pl | Wyższe Szkoły Bankowe' in self.driver.title

    
    def tearDown(self):
        self.driver.close()