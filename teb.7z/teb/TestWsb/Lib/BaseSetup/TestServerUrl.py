class Servertest(object):
    start_url = "http:www.wsb.pl"
