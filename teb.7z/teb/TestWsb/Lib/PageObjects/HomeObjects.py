from TestWsb.Lib.PageLocators.HomePageLocators import HomePageLocators 
import time

class HomeObject(object):
    def __init__(self, driver):
        self.driver = driver

    def clickcourses(self):
        courses = self.driver.find_element_by_xpath(HomePageLocators().studies_courses_btn)
        courses.click()
    
    def clickfirscycle(self):
        submenu = self.driver.find_element_by_xpath(HomePageLocators().fisrst_cycle_studies)
        self.driver.execute_script("arguments[0].click();", submenu)

    def clickfieldspec(self):
        self.driver.implicitly_wait(0.5)
        fieldspec = self.driver.find_element_by_xpath(HomePageLocators().field_of_studies_spec)
        fieldspec.click()

    def selectcity(self):
        self.driver.implicitly_wait(0.25)
        self.driver.find_element_by_id("app")
        selectcity = self.driver.find_element_by_xpath(HomePageLocators().select_Wro_city_checkbox)
        selectcity.click()
    
    def selectkindstudies(self):
        self.driver.implicitly_wait(0.25)
        self.driver.find_element_by_id("app")
        selectkindstudies = self.driver.find_element_by_xpath(HomePageLocators().select_inz_kind_studies)
        selectkindstudies.click()
        self.driver.implicitly_wait(1)
    
    def assert_images(self):
        time.sleep(1)
        actual_images = self.driver.find_elements_by_xpath(HomePageLocators().images)
        actual_images = len(actual_images)
        expected_images = 3
        print("actual number of images: " + str(actual_images))
        print("expected number of images: " + str(expected_images))
        assert actual_images == expected_images

    def assert_coursesnames(self):
        self.driver.implicitly_wait(1)
        actual_courses = self.driver.find_elements_by_xpath(HomePageLocators().coursesnames)
        actual_coursespage = len(actual_courses)
        expected_courses = 3
        print("actual number of courses: " + str(actual_coursespage))
        print("expected number of coursess: " + str(expected_courses))
        assert actual_coursespage == expected_courses

    def assert_coursescities(self):
        self.driver.implicitly_wait(1)
        actual_cities = self.driver.find_elements_by_xpath(HomePageLocators().coursescities)
        actual_citiespage = len(actual_cities)
        expected_cities = 3
        print("actual number of cities: " + str(actual_citiespage))
        print("expected number of cities: " + str(expected_cities))
        assert actual_citiespage == expected_cities

    def assert_button(self):
        actual_btn = self.driver.find_elements_by_xpath(HomePageLocators().signonline_btn)
        actual_signbtn = len(actual_btn)
        expected_button = 1
        assert actual_signbtn == expected_button
    
    def assert_filter(self):
        actual_filters = self.driver.find_elements_by_xpath(HomePageLocators().filters)
        actual_filterspage = len(actual_filters)
        expected_filters = 1
        assert actual_filterspage == expected_filters

    def assert_list(self):
        actual_list = self.driver.find_elements_by_xpath(HomePageLocators().listingcontent)
        actual_listpage = len(actual_list)
        expected_list = 1
        assert actual_listpage == expected_list

    def assert_listsort(self):
        actual_sort = self.driver.find_elements_by_xpath(HomePageLocators().listingsort)
        actual_listsort = len(actual_sort)
        expected_sort = 1
        assert actual_listsort == expected_sort

    def assert_listsearch(self):
        actual_search = self.driver.find_elements_by_xpath(HomePageLocators().listingsearch)
        actual_listsearch = len(actual_search)
        expected_search = 1
        assert actual_listsearch == expected_search

        

  